class ChannelsController < ApplicationController
	def index
		@pickall = Channel.all
	end
	def new
		@channel =Channel.new
	end
	def create
		@channel=Channel.new(channel_params)	
		if @channel.save
			flash[:notice] = "Article was saved"
			redirect_to channel_path(@channel)
		else
			render 'new'
		end
	end
	def update
		@channel=Channel.find(params[:id])
		if @channel.update(channel_params)
				flash[:notice] = "Article was udpated"
				redirect_to channel_path(@channel)
		else
			render 'edit'
	end
	end
	def edit
		@channel=Channel.find(params[:id])
	end

	def show
		@channel=Channel.find(params[:id])
	end
	def destroy
		@channel=Channel.find(params[:id])
		@channel.destroy!
		flash[:notice] = "Article was deleted sucessfully"
		redirect_to channel_path(@channel)
	end
	def channel_params
		params.require(:channel).permit(:title,:description)
	end
end